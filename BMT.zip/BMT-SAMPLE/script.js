let btnsend = document.querySelector('btn');
let message = document.querySelector('h1');

btnsend.addEventListener('click' , ()=>{
    btnsend.innerText = 'logging in';

    setTimeout(()=>{
        btnsend.style.display = "none";
        message.innerText = 'LOGOUT';
    },5000);
});