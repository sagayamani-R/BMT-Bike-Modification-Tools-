<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <!-- favcon -->
    <link id='favicon' rel="shortcut icon" href="images/logo.png" type="image/x-png">
    <title>About us</title>
</head>
<body>
    <div class="header">
            <div class="navbar">
                <div class="logo">
                  <img src="images/logo2.png" width="200px">
                </div>
            <nav>
                <ul>
                  <li><a href="../index.php">HOME</a></li>
                  <li><a href="../contact/index.php">CONTACT</a></li>
                  <li><a href="http://localhost/BMT-SAMPLE/login/login.php">LOGIN</a></li>
                </ul>
            </nav>
            </div>
     </div>
    <div class="container">
        <video autoplay loop muted plays-inline class="background-clip">
            <source src="images/background.mp4" type="video/mp4">
        </video>
        <div class="content">
            <h1>WELCOME BIKER!</h1>
            <a href="#about us">About us</a>
        </div>
    </div>
    <h2 class="title-1" id="about us">ABOUT US</h2>
    <div class="paragraph" >
        <div class="paragraph-img">
            <img src="images/logo2.png" >
        </div>
        <div class="paragraph-words">
            <h2>Welcome to BMT!</h2><br> 
            BMT-BIKE MODIFICATION TOOL is a online bike modification spare parts selling website.
            This platform is designed to provide easy and convenient access to a wide range of bike modification spare parts for customers.
            The website features a user friendly interface that enables customers to purchase easily. 
            This is a user friendly website which the user can easily interact.
            Another feature is to have the list of product available for buying.
            For this e-commerce website we provide cart functionality module to add the item of the buyer's wish and price history list module for bike spare parts .
            This is an another feature which show the price history of bike parts over a certain period of time. 
            This price history list for bike parts is an important tool for users to purchase the product at the best time. 
            Product page with detail information about each product, including photos, price and specification who value convenience reliability and affordability.
            Registration module which a user create an account on this website and login module is a gateway for the user to access the available products. 
            Admin can check the details of the user those who have registered and login in this website through the login database. 
            The main objective is to overcome the manual error and make a computerized system. 
        </div>
    </div><br>
    <h2 class="title-1">OUR ADMINS</h2>
    <div class="admins">
        <div class="card-1">
            <div class="card-image">
                <img src="./images/nishanth.jpg" alt="Profile image">
            </div>
            <p class="name">NISHANTH</p>
            <p>UX / UI developer</p>
            <p>Hi im Nishanth im the co-leader of this website.I handle the designing side of this website.for more details contact me on below links</p>
            <div class="socials">
                <a href="https://wa.me/919176895094"><button class="whatsapp"><i class="fab fa-whatsapp"></i></button></a>
                <button class="instagram"><i class="fab fa-instagram"></i></button>
                <button class="pinterest"><i class="fab fa-pinterest-p"></i></button>
            </div>
        </div><br>
        <div class="card-2">
            <div class="card-image">
                <img src="./images/rose3.png" alt="Profile image">
            </div>
            <p class="name">NAVAMANI</p>
            <p>Front-End developer</p>
            <p>Hi im Navamani im the Leader of this website. And I handle the Front-end side of this website.for more details contact me on below links.</p>
            <div class="socials">
                <button class="whatsapp"><i class="fab fa-whatsapp"></i></button>
                <button class="instagram"><i class="fab fa-instagram"></i></button>
                <button class="pinterest"><i class="fab fa-pinterest-p"></i></button>
            </div>
            
        </div><br>
        <div class="card-3">
            <div class="card-image">
                <img src="./images/nareshkumar.jpg" alt="Profile image">
            </div>
            <p class="name">NARESH KUMAR</p>
            <p>Back-End developer</p>
            <p>Hi im Naresh kumar im the Member  of this website. And I handle the Back-end side of this website.for more details contact me on below links.</p>
            <div class="socials">
                <button class="whatsapp"><i class="fab fa-whatsapp"></i></button>
                <button class="instagram"><i class="fab fa-instagram"></i></button>
                <button class="pinterest"><i class="fab fa-pinterest-p"></i></button>
            </div>
        </div>
    </div>
    <h2 class="title-1">FEEDBACK</h2>
    <div class="feedback">
        </div>
    <div class="contact-form">
        <form method="post" action="feedbackDB.php">
          <h3 class="title">GIVE US YOUR VALUABLE FEEDBACK</h3>
          <div class="input-container">
            <input type="text" name="name" class="input" />
            <label for="">Username</label>
            <span>Username</span>
          </div>
          <div class="input-container">
            <input type="email" name="email" class="input" />
            <label for="">Email</label>
            <span>Email</span>
          </div>
          <div class="input-container textarea">
            <textarea name="message" class="input"></textarea>
            <label for="">Message</label>
            <span>Message</span>
          </div>
          <input type="submit" value="Send" class="btn" />
        </form>
      </div>
      </div>

    <!-- footer starts -->
    <section class="footer">

        <div class="box-container">
      
            <div class="box">
                <h3>BMT </h3>
                <p>Thanks for visiting us . <br><br>Keep Rising 🚀. <br><br>Connect with us  over the media!</p>
            </div>
      
            <div class="box">
                <h3>quick links</h3>
                <a href="../index.php"><i class="fas fa-chevron-circle-right"></i> home</a>
                <a href="../contact/index.php"><i class="fas fa-chevron-circle-right"></i>Contact</a>
                <a href="#featured"><i class="fas fa-chevron-circle-right"></i>products</a>
                <a href="http://localhost/BMT-SAMPLE/login/login.php"><i class="fas fa-chevron-circle-right"></i>login</a>
            </div>

            <div class="box">
                <h3>contact info</h3>
                <p> <i class="fas fa-phone"></i>+91 6374366680</p>
                <p> <i class="fas fa-envelope"></i>navamani4777@gmail.com</p>
                <p> <i class="fas fa-map-marked-alt"></i>TamilNadu,India-6000018</p>
                <div class="share">
      
                    <a href="https://wa.me/916374366680" class="fab fa-whatsapp" aria-label="watsapp" target="_blank"></a>
                    <a href="https://www.snapchat.com/add/hari_b2k?share_id=zfjbsiKIBbk&locale=en-IN" class="fab fa-snapchat-square" aria-label="snapchat" target="_blank"></a>
                    <a href="www.navamani4777@gmail.com" class="fas fa-envelope" aria-label="Mail" target="_blank"></a>
                    <a href="https://m.facebook.com/100028872458843/" class="fab fa-facebook" aria-label="facebook" target="_blank"></a>
                    <a href="https://www.instagram.com/hari_fury/?igshid=OGQ2MjdiOTE%3D" class="fab fa-instagram" aria-label="instagram" target="_blank"></a>
                </div>
            </div>
        </div>
    </section>
      <!-- footer section ends -->
      <script src="app.js"></script>
</body>
</html>