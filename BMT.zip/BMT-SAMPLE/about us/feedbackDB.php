<?php
// connecting database
$conn=mysqli_connect("localhost","root","","bmt");
$uname=$_POST['name'];
$umail=$_POST['email'];
$msg=$_POST['message'];
$sql="INSERT INTO `feedback`(`name`, `email`,`message`) VALUES ('$uname','$umail','$msg')";
$insert=mysqli_query($conn,$sql);
if(!$insert){
    echo "ERORR";
}
else
{
    header("location: index.php");
}
?>