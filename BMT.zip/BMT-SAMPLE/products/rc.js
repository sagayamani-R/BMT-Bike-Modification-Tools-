
let x = [];


// setTimeout(() => {
//     for (let i = 0; i < x.length; i++) {
//         let title = x[i].title;
//         let price = x[i].price;
//         // let title = x[i].title;
//         console.log('title :'+title , 'price :'+price);
        
//     }
// }, 6000);

title = 'hikuh';

console.log("name"+title);


let rcVisor = ()=>{
    
    //  a = [{
    //     'title':'Rc Visor',
    //     'colour':'Transperent',
    //     'Quality':'PremiumQuality',
    //     'installation':'Easy installation',
    //     'price':'1899'
    // }];

    x.push({
        'title':'Rc Visor',
        'colour':'Transperent',
        'Quality':'PremiumQuality',
        'installation':'Easy installation',
        'price':'1899'
    });

    title = 'Rc Visor'
    
    // console.log(a);
    
}

let rCRadiatorGaurd = ()=>{
    x.push({
        'title':'Radiator Gaurd',
        'colour':'Transperent',
        'Quality':'PremiumQuality',
        'installation':'Easy installation',
        'price':'1899'
    });
}

let rCCover = ()=>{

    x.push({
        'title':'Rc cover',
        'colour':'Transperent',
        'Quality':'PremiumQuality',
        'installation':'Easy installation',
        'price':'1899'
    });    

}









console.log(x);