<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MT-15</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="./mt.css">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="header">
        <div class="container">
            <div class="navbar">
                <div class="logo">
                  <img src="../images/logo.png" width="125px">
                </div>
            <nav>
                <ul>
                  <li><a href="../index.php">HOME</a></li>
                  <li><a href="../about us/aboutus.php">ABOUT</a></li>
                  <li><a href="../contact/index.php">CONTACT</a></li>
                  <li><a href="../login/login.php">LOGIN</a></li>
                </ul>
            </nav>
            <i class="fas fa-shopping-cart"></i>
    
        </div>
            <div class="row">
                <div class="col-2">
                    <h1>MT-15<br>MOVE IN STYLE</h1>
                </div>
                <div class="col-2">
                    <img src="../images/mt-15.png">
                </div>
    
            </div>
    <div class="small-container" id="featured">
        <h2 class="title">MT-15's products</h2>
        <div class="row">
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/mt-15 visor.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Bike Metal Visor</h3><br>
    <p class="card-text">
      <ul>
        <li>colour: Black</li>
        <li>Premium Quality Mild Stee</li>
        <li>Easy installation</li>
        <h3>Rs.399 Only</h3> 
        <div class="rating">
          <i class="fa fa-star"></i>
          <i class="fa fa-star"></i>
          <i class="fa fa-star"></i>
          <i class="fa fa-star"></i>
          <i class="fa fa-star-half stroke"></i>                
      </div>
      </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/radiator gaurd.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Radiator Gaurd</h3><br>
    <p class="card-text">
    <ul>
      <li>Raditor gaurd grill only</li>
      <li>Made with stainless steel</li>
      <li>Easy installation</li>
      <h3>Rs.699 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 cover.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Cover</h3><br>
    <p class="card-text">
    <ul>
      <li>Color: Maroon color</li>
      <li>Dust proof cover</li>
      <li>Full body protection</li>
      <h3>Rs.389 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 carrier.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Luggage Carrier</h3><br>
    <p class="card-text">
    <ul>
      <li>Color: Black</li>
      <li>Made with mild steel</li>
      <li>with 1 year warrenty</li>
      <h3>Rs.1444 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 crash protector.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Crash protector</h3><br>
    <p class="card-text">
    <ul>
      <li>Color: Gold and Black</li>
      <li>Made with CNC Aluminum</li>
      <li>Protects from crashes</li>
      <h3>Rs.899 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 dragon sticker.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Eye sticker</h3><br>
    <p class="card-text">
    <ul>
      <li>Dragon eye sticker</li>
      <li>Made with Vinyl</li>
      <li>Fade resistance</li>
      <h3>Rs.499 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 air filter.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Air filter cover</h3><br>
    <p class="card-text">
      <ul>
        <li>color: Golden yellow</li>
        <li>Made with carbon steel</li>
        <li>Durable and Eco-friendly</li>
        <h3>Rs.499 Only</h3> 
        <div class="rating">
          <i class="fa fa-star"></i>
          <i class="fa fa-star"></i>
          <i class="fa fa-star"></i>
          <i class="fa fa-star"></i>
          <i class="fa fa-star"></i>                
        </div>
      </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 tank sticker.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Tank pad</h3><br>
    <p class="card-text">
    <ul>
      <li>Color:Black</li>
      <li>Protects tank from damage</li>
      <li>Suitable for MT-15</li>
      <h3>Rs.350 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 oil cap gaurd.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Oil cap gaurd</h3><br>
    <p class="card-text">
    <ul>
      <li>Enhance the apperance</li>
      <li>Made with stainless steel</li>
      <li>Higher durability</li>
      <h3>Rs.299 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 screen protector.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Screen protector</h3><br>
    <p class="card-text">
    <ul>
      <li>9h scratch resistance matirial</li>
      <li>chatter proof and bobble free</li>
      <li>Higher transperency </li>
      <h3>Rs.289 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
  </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 exhaust cover.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Exhaust cover</h3><br>
    <p class="card-text">
    <ul>
      <li>Color: Golden yellow</li>
      <li>Gives premium lookl</li>
      <li>Weather resistance</li>
      <h3>Rs.1199 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
           <div class="col-4">
            <div class="card" style="width: 18rem;">
  <img src="../images/MT-15 winglet.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h3 class="card-title">MT-15 Winglet</h3><br>
    <p class="card-text">
    <ul>
      <li>Color: Green</li>
      <li>Made with ABS Plastic</li>
      <li>gives enhanced look</li>
      <h3>Rs.263 Only</h3> 
      <div class="rating">
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star-half stroke"></i>                
      </div>
    </ul>
    </p>
    <a href="#" class="btn btn-primary">Buy Now</a>
  </div>
</div>
           </div>    
          
 
    </div>
        </div>
     </div>
    <div class="small-container" id="featured">
      <h2 class="title">Last month price list</h2>
    </div>
     <!--table-->
    
     <div class="container">
      <div class="table"> 
        <table class="table table-hover">
          <thead class="table-dark">
          <tr>
              <th>PRODUCT</th>
              <th>01/03/2025</th>
              <th>07/03/2025</th>
              <th>14/03/2025</th>
              <th>21/03/2025</th>
              <th>28/03/2025</th>
              <th>31/03/2025</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // connecting database
             $conn=mysqli_connect("localhost","root","","bmt");
             $sql="SELECT * FROM mt15";
             $connect=mysqli_query($conn,$sql);
             $num=mysqli_num_rows($connect); //check database that it has any value
             if ($num>0){
              while($data=mysqli_fetch_assoc($connect)){
                echo "
                    <tr>
                      <td>".$data['product']."</td>
                      <td>".$data['01/03/2023']."</td>
                      <td>".$data['07/03/2023']."</td>
                      <td>".$data['14/03/2023']."</td>
                      <td>".$data['21/03/2023']."</td>
                      <td>".$data['28/03/2023']."</td>
                      <td>".$data['31/03/2023']."</td>
                    </tr>
                    ";
              }
             }
            ?>
          </tbody>
        </table>
        </div>
     </div>
      <!----footer-->
    <section class="footer">

      <div class="box-container">
    
          <div class="box">
              <h3>BMT </h3>
              <p>Thanks for visiting us . <br><br>Keep Rising 🚀. <br><br>Connect with us  over the media!</p>
          </div>
    
          <div class="box">
              <h3>quick links</h3>
              <a href="../index.php"><i class="fas fa-chevron-circle-right"></i> home</a>
              <a href="../about us/aboutus.php"><i class="fas fa-chevron-circle-right"></i> about</a>
              <a href="#featured"><i class="fas fa-chevron-circle-right"></i>products</a>
              <a href="../login/login.php"><i class="fas fa-chevron-circle-right"></i>login</a>
          </div>

          <div class="box">
              <h3>contact info</h3>
              <p> <i class="fas fa-phone"></i>+91 8098842262</p>
              <p> <i class="fas fa-envelope"></i>harishanmu2409@gmail.com</p>
              <p> <i class="fas fa-map-marked-alt"></i>TamilNadu,India-6000018</p>
              <div class="share">
    
                  <a href="https://wa.me/919600028431" class="fab fa-whatsapp" aria-label="watsapp" target="_blank"></a>
                  <a href="https://www.snapchat.com/add/hari_b2k?share_id=zfjbsiKIBbk&locale=en-IN" class="fab fa-snapchat-square" aria-label="snapchat" target="_blank"></a>
                  <a href="www.harishanmu2409@gmail.com" class="fas fa-envelope" aria-label="Mail" target="_blank"></a>
                  <a href="https://m.facebook.com/100028872458843/" class="fab fa-facebook" aria-label="facebook" target="_blank"></a>
                  <a href="https://www.instagram.com/hari_fury/?igshid=OGQ2MjdiOTE%3D" class="fab fa-instagram" aria-label="instagram" target="_blank"></a>
              </div>
          </div>
      </div>
  </section>
    <!-- footer section ends -->
</body>
</html>