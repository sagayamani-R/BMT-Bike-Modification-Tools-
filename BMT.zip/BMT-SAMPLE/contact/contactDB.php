<?php
// connecting database
$conn=mysqli_connect("localhost","root","","bmt");
$uname=$_POST['name'];
$umail=$_POST['email'];
$unumber=$_POST['phone'];
$msg=$_POST['message'];
$sql="INSERT INTO `contact`(`username`, `email`, `phone`, `message`) VALUES ('$uname','$umail',$unumber,'$msg')";
$insert=mysqli_query($conn,$sql);
if(!$insert){
    echo "ERORR";
}
else
{
    header("location: index.php");
}
?>