<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BMT</title>
    <link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <div class="container">
        <div class="title">BMT CHATBOT<span style='font-size:40px;''>&#129302;</span>
        </div>
        <div class="chat" id="chat"></div>
        <input type="text" class="input" id="input" placeholder="Type your message here...." />
        <button class="button" id="button"><i class="fa-brands fa-telegram"></i></button>
      </div>
      <a href="../index.php">
      <button class="homebtn">HOME</button></a>

      
      <script src="script.js"></script>
</body>
</html>