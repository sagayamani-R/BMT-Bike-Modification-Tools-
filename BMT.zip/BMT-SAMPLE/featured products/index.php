<!-- connecting database -->
<?php
     include "productsdb.php"
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add products</title>
</head>
<body>
    <h1>Add products</h1>
    <form method="post" enctype="multipart/form-data">
        <input type="file" name="image">
        <input type="submit" name="submit" value="save">
    </form>
    <?php
        if(isset($_POST["submit"]))
        {
          if(getimagesize($_FILES['image']['tmp_name'])==false)
          {
            echo "please select image";
          }
          else
          {
            // echo "you can store";
            $image=$_FILES['image']['tmp_name'];
            $name=$_FILES['image']['name'];
            $image=file_get_contents($image);
            $image=base64_encode($image);
            $sql="INSERT INTO FEATURED_PRODUCTS (NAME,IMAGE)VALUES('$name','$image')";
            if($con->query($sql))
            {
                echo "image stored";
            }
            else
            {
                echo "error";
            }
          }
        }
        else
        {
            echo "please select a image to save";
        }
        $sql="SELECT * FROM FEATURED_PRODUCTS";
        $result=$con->query($sql);
        if($result->num_rows>0)
        {
            while($row=$result->fetch_assoc())
                {
                    echo "<img width='300px'
                    height='300px'src='data:image;base64,{$row["image"]}'
                    alt='img'>";
                    echo "<br><hr>";
                }
        }
        else
        {
            echo "No Images stored";
        }
    ?>
</body>

</html>