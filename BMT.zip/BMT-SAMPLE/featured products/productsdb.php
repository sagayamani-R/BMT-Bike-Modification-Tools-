<?php
$con=mysqli_connect("localhost","root","","bmt");
if($con){
    // echo "connected";
}
else{
    echo "not connected";
}
?>