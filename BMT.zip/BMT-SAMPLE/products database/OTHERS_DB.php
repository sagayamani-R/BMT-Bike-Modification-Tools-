<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>OTHERS-DB</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./MT-15.css">
</head>
<body>
    <div class="header">
    <div class="container">
        <div class="navbar">
            <div class="logo">
              <img src="../images/logo.png" width="200px">
            </div>
        </nav>
    </div>
 </div>
    <center><h1 style="color:white;">OTHER product price<h1></center><br><br><br>
    <div class="container">
        <div class=" table form"></div>
            <table>
                <form action="Insert-OTHERS.php" method="post">
                <tr>
                    <th style="color:white;">PRODUCT</th>
                    <td><input type="text" placeholder="product name" name="product"><td>
                </tr>
                <tr>
                    <th style="color:white;">01/03/2023</th>
                    <td><input type="number" placeholder="product price" name="01"><td>
                </tr>
                <tr>
                    <th style="color:white;">07/03/2023</th>
                    <td><input type="number" placeholder="product price" name="07"><td>
                </tr>
                <tr>
                    <th style="color:white;">14/03/2023</th>
                    <td><input type="number" placeholder="product price" name="14"><td>
                </tr>
                <tr>
                    <th style="color:white;">21/03/2023</th>
                    <td><input type="number" placeholder="product price" name="21"><td>
                </tr>
                <tr>
                    <th style="color:white;">28/03/2023</th>
                    <td><input type="number" placeholder="product price" name="28"><td>
                </tr>
                <tr>
                    <th style="color:white;">31/03/2023</th>
                    <td><input type="number" placeholder="product price" name="31"><td>
                </tr>
                <tr>
                    <td></td>
                    <td><button type="submit">INSERT</button></td>
                </tr>
                </form>
            </table>            
    </div>
</body>
</html>



                    