<?php
// connecting database
$conn=mysqli_connect("localhost","root","","bmt");
$name=$_POST['product'];
$_01=$_POST['01'];
$_07=$_POST['07'];
$_14=$_POST['14'];
$_21=$_POST['21'];
$_28=$_POST['28'];
$_31=$_POST['31'];
$sql="INSERT INTO `r15`(`product`, `01/03/2023`, `07/03/2023`, `14/03/2023`, `21/03/2023`, `28/03/2023`, `31/03/2023`) VALUES ('$name',$_01,$_07,$_14,$_21,$_28,$_31)";
$insert=mysqli_query($conn,$sql);
if(!$insert){
    echo "ERORR";
}
else
{
    header("location: R15_DB.php");
}
?>