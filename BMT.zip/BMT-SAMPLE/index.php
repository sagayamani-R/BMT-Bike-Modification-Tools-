<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FURY RIDERS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.1/css/fontawesome.min.css" integrity="sha384-QYIZto+st3yW+o8+5OHfT6S482Zsvz2WfOzpFSXMF9zqeLcFV0/wlZpMtyFcZALm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<div class="chatbot">
    <a href="chatbot\index.php">
        <img src="images\images-removebg-preview.png" alt="" >
    </a>
</div>
<div class="header">
    <div class="container">
        <div class="navbar">
            <div class="logo">
              <img src="./images/logo.png" width="200px">
            </div>
        <nav>
            <ul>
              <li><a href="index.php">HOME</a></li>
              <li><a href="#featured">PRODUCT</a></li>
              <li><a href="about us/aboutus.php">ABOUT</a></li>
              <li><a href="contact/index.php">CONTACT</a></li>
              <li><a href="login/login.php" class="btn" id="login">LOGIN</a></li>
              <h1></h1>
            </ul>
        </nav>
        <a href=""><i class="fas fa-shopping-cart"> </i> </a>
<h3 style="color:white;" text-indent: 50px;>
    <?php
    include "login/db.php";
    // session_start();
    // echo $_SESSION["username"];
    // $user=$_SESSION['username'];
    // $query=mysqli_query($con,"select * from register where username = '$user'");
    // $id=$un['id'];
    ?>
</h3>

        </div>
        <div class="row">
            <div class="col-2">
                <h1>UPGRADE YOUR BEAST IN NEW STYLE</h1>
                <a href="#featured" class="btn">EXPLORE NOW &#8594</a>
            </div>
            <div class="col-2">
                <!-- <img src="/images/mt-15.png"> -->
            </div>

        </div>
    </div>
 </div>
<!------ featured categories ------>
   <div class="categories">
    <div class="small-container">
      <div class="row">
       <div class="col-3">
            <a href="./products/helmet.php"><img src="images/helmet (3).png"></a>
        </div>
        <div class="col-3">
            <a href="./products/gears.php"><img src="images/glove.png"></a>
        </div>
        <div class="col-3">
            <a href="./products/others.php"><img src="images/gadgets.jpeg"></a>
        </div>
      </div>
   </div>
</div>
<!-- featured products-->
<div class="small-container" id="featured">
        <h2 class="title">featured products</h2>
        <div class="row">
            <div class="container-xxl">
                <?php
                    include "featured products/productsdb.php";
                    $sql="SELECT * FROM FEATURED_PRODUCTS";
                    $result=$con->query($sql);
                    if($result->num_rows>0)
                    {
                        while($row=$result->fetch_assoc())
                            {
                                echo "<img width='300px'
                                height='300px'src='data:image;base64,{$row["image"]}'
                                alt='img'>";
                            }
                    }
                    else
                    {
                        echo "No Images stored";
                    }
                ?>
            </div>
        </div>
</div>
<!-- displaying bikes -->
    <div class="small-container" id="featured">
        <h2 class="title">Available products</h2>
        <div class="row">
            <div class="col-4">
                <a href="./products/mt.php">
                    <img src="images/mt-15 (2).png" class="mt">
                </a>
            </div>
            <div class="col-4">
                <a href="./products/rs.php">
                    <img src="images/rs.png" class="rs">
                </a>
            </div>
            <div class="col-4">
                <a href="./products/ns.php">
                    <img src="images/ns.png" class="ns">
                </a>
            </div>
            <div class="col-4">
                <a href="./products/r15.php">
                    <img src="images/v4.png" height="300px" width="300px" class="v4">
                </a>
            </div>
            <div class="col-4">
                <a href="./products/duke.php">
                    <img src="images/duke.png" class="duke">
                </a>
            </div>
            <div class="col-4">
                <a href="./products/rc.php">
                    <img src="images/rc.jpg" width="250px" height="250px" class="rc">
                </a>
            </div>
            <div class="col-4">
                <a href="./products/gt650.php">
                    <img src="images/gt650.jpg" class="gt650">
                </a>
            </div>
            <div class="col-4">
                <a href="./products/gixxer.php">
                    <img src="images/gixxer.png" width="1000px" height="250px" class="gixxer">
                </a>
            </div>
        </div>    
       
    </div>
<!--offer-->
    <div class="offer">
        <div class="small-container">
            <div class="row">
                <div class="col-2">
                    <img src="images/gps.png" class="offer-img">
                </div>
                <div class="col-2">
                    <p>Exclusivly Available on<h3>BMT</h3></p>
                    <h1>Onelap GPS for motor bikes</h1>
                    <small>the Onelap GPS is one of the most wanted gadget for bike.this GPS provides higher security to your motor cycle</small>
                    <a href="" class="btn">Buy Now &#8594;</a>
                </div>
            </div>
        </div>
    </div>
    <!--testimonial-->
    <div class="testimonial">
        <div class="small-container">
            <div class="row">
                <div class="col-3">
                    <i class="fa fa-quote-left"></i>
                    <p>welcome to the great kirikalan magic show!!!  </p>
                    <div class="rating">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-o"></i>                    
                    </div>
                    <img src="images/nitish.jpg">
                    <h3>NITISH</h3>
                </div>
                <div class="col-3">
                    <i class="fa fa-quote-left"></i>
                    <p>Nanbargale! ithu namma thambi webite tha romba chinna website. nambi vangalam athuku na gaurantee. Chinna website tha unga atharava thanthu thambiya periyala aki vidunga </p>
                    <div class="rating">
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star-o"></i>                    
                    </div>
                    <img src="images/gpmuthu.jpg">
                    <h3>GP Muthu</h3>
                </div>
                <div class="col-3">
                   <i class="fa fa-quote-left"></i>
                   <p>Nambi vangalam appdi sonnatha sorunu solranunga vera vali nambi vanitha aganum  </p>
                   <div class="rating">
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star"></i>
                       <i class="fa fa-star-o"></i>                    
                    </div>
                    <img src="images/rider.jpg">
                    <h3>prakash guru</h3>
                </div>
            </div>
        </div>
    </div>
    <!----- brands-->
    <div class="brands">
        <div class="small-container">
            <div class="row">
                <div class="col-5">
                    <img src="images/ktm.png" width="125" height="125">
                </div>
                <div class="col-5">
                    <img src="images/yamaha.png" width="125" height="125">
                </div>
                <div class="col-5">
                    <img src="images/re.png" width="150" height="150">
                </div>
                <div class="col-5">
                    <img src="images/bajaj.png" width="125" height="125">
                </div>
                <div class="col-5">
                    <img src="images/suzuki.png" width="125" height="125">
                </div>
            </div>
        </div>
    </div>
    <!----footer-->
    <section class="footer">

        <div class="box-container">
      
            <div class="box">
                <h3>BMT </h3>
                <p>Thanks for visiting us . <br><br>Keep Rising 🚀. <br><br>Connect with us  over the media!</p>
            </div>
      
            <div class="box">
                <h3>quick links</h3>
                <a href="index.php"><i class="fas fa-chevron-circle-right"></i> home</a>
                <a href="about us/aboutus.php"><i class="fas fa-chevron-circle-right"></i> about</a>
                <a href="#featured"><i class="fas fa-chevron-circle-right"></i>products</a>
                <a href="login/login.php"><i class="fas fa-chevron-circle-right"></i>login</a>
            </div>

            <div class="box">
                <h3>contact info</h3>
                <p> <i class="fas fa-phone"></i>+91 6374366680</p>
                <p> <i class="fas fa-envelope"></i>navamani4777@gmail.com</p>
                <p> <i class="fas fa-map-marked-alt"></i>TamilNadu,India-6000018</p>
                <div class="share">
      
                    <a href="https://wa.me/916374366680" class="fab fa-whatsapp" aria-label="watsapp" target="_blank"></a>
                    <a href="https://www.snapchat.com/add/hari_b2k?share_id=zfjbsiKIBbk&locale=en-IN" class="fab fa-snapchat-square" aria-label="snapchat" target="_blank"></a>
                    <a href="www.navamani4777@gmail.com" class="fas fa-envelope" aria-label="Mail" target="_blank"></a>
                    <a href="https://m.facebook.com/100028872458843/" class="fab fa-facebook" aria-label="facebook" target="_blank"></a>
                    <a href="https://www.instagram.com/i_am_your_old_friend/?igshid=OGQ2MjdiOTE%3D" class="fab fa-instagram" aria-label="instagram" target="_blank"></a>
                </div>
            </div>
        </div>
    </section>
      <!-- footer section ends -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="script.js"></script>
</body>
</html>