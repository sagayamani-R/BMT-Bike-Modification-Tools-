 <?php session_start(); ?>
<h1> WELCOME <?php echo $_SESSION["username"]; ?></h1>
<a href="logout.php">Back to home</a>
