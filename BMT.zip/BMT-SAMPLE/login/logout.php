<?php
session_start();
session_destroy();
header("location: http://localhost/BMT-SAMPLE/index.php");

?>