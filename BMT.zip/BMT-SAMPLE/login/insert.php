<?php
// connecting the database
include "db.php";
// getting values from register
$un=$_POST['username'];
$pwd=$_POST['password'];
$email=$_POST['email'];
// storing values to database
$sql="insert into register(username,password,email) 
        values ('$un','$pwd','$email')";
// showing input data
$result=mysqli_query($con,$sql);
if($result){
    header("location: login.php");
}
else{
    echo "ERROR";
}

?>