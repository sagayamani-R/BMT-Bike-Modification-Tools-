<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
 
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <form action="select.php" method="post">
        <h3>Login Here</h3>

        <label for="username">Username</label>
        <input type="text" autocomplete="off" placeholder="Email or Phone" id="username" name="username" />

        <label for="password">Password</label>
        <input type="password" placeholder="Password" id="password" name="password" />

        <button>Log In</button>
        <div class="social">
          <h4>new user?  <a href="register.php">register</a></h4>
        </div>
    </form>
</body>
</html>
