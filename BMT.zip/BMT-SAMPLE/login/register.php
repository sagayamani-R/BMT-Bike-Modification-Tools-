<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register</title>
 
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="register.css">
</head>
<body>
    <form action="insert.php" method="post">
        <h3>Register Here</h3>
        <label for="username">Username</label>
        <input type="text" autocomplete="off" placeholder="enter name" id="username" name="username" />
        <label for="password">Password</label>
        <input type="password" placeholder=" enterPassword" id="password" name="password" />
        <label for="password">Email</label>
        <input type="email" placeholder="enter email" id="email" name="email" />
        <button>Register</button>
    </form>
</body>
</html>
